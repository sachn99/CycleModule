package cycle.component;

public interface SeatPlanner {
	float getPrice(String orderDate);
}
