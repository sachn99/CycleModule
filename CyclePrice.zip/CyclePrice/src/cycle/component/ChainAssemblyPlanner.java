package cycle.component;

public interface ChainAssemblyPlanner {
	float getPrice(String orderDate);

}
