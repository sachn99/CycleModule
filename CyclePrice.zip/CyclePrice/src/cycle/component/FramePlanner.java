package cycle.component;

import java.util.Date;

public interface FramePlanner {

	float getPrice(String orderDate);
}
