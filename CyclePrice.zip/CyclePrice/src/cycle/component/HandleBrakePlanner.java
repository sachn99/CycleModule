package cycle.component;

public interface HandleBrakePlanner {
	float getPrice(String orderDate);

}
