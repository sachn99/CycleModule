package cycle.component;

public interface  WheelPlanner {

	float getPrice(String ComponentName);

}
